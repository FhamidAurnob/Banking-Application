package bankingapplication;
public class BankingApplication {

    public static void main(String[] args) {
       new login().setVisible(true);
    }
    
}
